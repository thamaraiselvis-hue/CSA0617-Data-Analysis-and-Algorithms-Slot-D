import java.io.*;
import java.nio.file.*;
import java.util.*;

/** A2 / B1.3 - count lines in a file: unbuffered (1 byte per read), buffered, and readAllLines. */
public class LineCounter {
    static long readCalls;

    static long countUnbuffered(Path p) throws IOException {
        long lines = 0; readCalls = 0;
        try (FileInputStream in = new FileInputStream(p.toFile())) {
            int b;
            while ((b = in.read()) != -1) { readCalls++; if (b == '\n') lines++; }   // one OS call per byte
            readCalls++;
        }
        return lines;
    }
    /** Buffered: the stream is read in 8 KB blocks (one read() call per block, not per byte). */
    static long countBuffered(Path p) throws IOException {
        long lines = 0; readCalls = 0;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(p.toFile()), 8192)) {
            byte[] bb = new byte[8192]; int m;
            while ((m = in.read(bb)) != -1) { readCalls++; for (int i = 0; i < m; i++) if (bb[i] == '\n') lines++; }
        }
        return lines;
    }
    static long countBufferedReaderLines(Path p) throws IOException {
        long lines = 0;
        try (BufferedReader br = Files.newBufferedReader(p)) { while (br.readLine() != null) lines++; }
        return lines;
    }
    static long countReadAllLines(Path p) throws IOException { return Files.readAllLines(p).size(); }

    static Path makeFile(String name, long targetBytes) throws IOException {
        Path p = Paths.get("data", name);
        if (Files.exists(p) && Files.size(p) >= targetBytes) return p;
        Random r = new Random(42);
        try (BufferedWriter w = Files.newBufferedWriter(p)) {
            long written = 0;
            while (written < targetBytes) {
                String l = String.format("2026-11-%02d,192311%03d,IN,%02d:%02d:%02d", r.nextInt(28) + 1, r.nextInt(999),
                        r.nextInt(24), r.nextInt(60), r.nextInt(60));
                w.write(l); w.newLine(); written += l.length() + 1;
            }
        }
        return p;
    }

    static double timeMs(java.util.concurrent.Callable<Long> c, long[] out) throws Exception {
        long t = System.nanoTime(); out[0] = c.call(); return (System.nanoTime() - t) / 1e6;
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Paths.get("data"));
        long[] sizes = {1L << 20, 10L << 20, 50L << 20};
        String[] names = {"log_1MB.txt", "log_10MB.txt", "log_50MB.txt"};
        // warm-up so the JIT is not measured
        Path w = makeFile("log_1MB.txt", sizes[0]); countBuffered(w); countBufferedReaderLines(w);
        System.out.println("Size  | Unbuffered ms |   read() calls | Buffered ms | read() calls | readLine ms | readAllLines ms |     Lines");
        System.out.println("------+---------------+----------------+-------------+--------------+-------------+-----------------+----------");
        for (int i = 0; i < 3; i++) {
            Path p = makeFile(names[i], sizes[i]);
            long[] o = new long[1];
            double tu = timeMs(() -> countUnbuffered(p), o); long callsU = readCalls, linesU = o[0];
            double tb = timeMs(() -> countBuffered(p), o);   long callsB = readCalls, linesB = o[0];
            double tl = timeMs(() -> countBufferedReaderLines(p), o);
            double ta = timeMs(() -> countReadAllLines(p), o);
            if (linesU != linesB) throw new IllegalStateException("line counts differ");
            System.out.printf("%-5s | %13.1f | %,14d | %11.1f | %,12d | %11.1f | %15.1f | %,9d%n",
                    (sizes[i] >> 20) + " MB", tu, callsU, tb, callsB, tl, ta, linesU);
        }
    }
}
