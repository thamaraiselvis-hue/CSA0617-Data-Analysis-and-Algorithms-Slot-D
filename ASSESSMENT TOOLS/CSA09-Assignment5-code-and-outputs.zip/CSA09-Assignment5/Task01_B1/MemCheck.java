import java.io.*;
import java.nio.file.*;
import java.util.*;

/** A2 Alternative - memory used by Files.readAllLines() on the 50 MB log versus a streaming BufferedReader. */
public class MemCheck {
    static long used() { Runtime r = Runtime.getRuntime(); for (int i = 0; i < 3; i++) System.gc(); return r.totalMemory() - r.freeMemory(); }
    public static void main(String[] a) throws Exception {
        Path p = Paths.get("data", "log_50MB.txt");
        long base = used();
        List<String> all = Files.readAllLines(p);
        long after = used();
        System.out.printf("readAllLines : %,d lines held in memory, extra heap = %.1f MB for a %.1f MB file (%.1fx the file size)%n",
                all.size(), (after - base) / 1048576.0, Files.size(p) / 1048576.0, (after - base) / (double) Files.size(p));
        all = null; base = used(); long peak = 0; long n = 0;
        try (BufferedReader br = Files.newBufferedReader(p)) { String l; while ((l = br.readLine()) != null) { n++; if (n % 100000 == 0) peak = Math.max(peak, used() - base); } }
        System.out.printf("BufferedReader.readLine : %,d lines processed one at a time, extra heap while reading = about %.2f MB (a few buffers)%n", n, Math.max(peak, 0) / 1048576.0);
    }
}
