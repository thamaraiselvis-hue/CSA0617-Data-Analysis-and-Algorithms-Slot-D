import java.io.*;
import java.nio.file.*;
import java.util.*;

/** B1.4 - time to find a pass as the file grows (worst case = last record), plus the Alternative Concepts. */
public class GrowthBench {
    static final int REC = 64; // fixed record size for the RandomAccessFile alternative

    static Path build(int n) throws IOException {
        Path p = Paths.get("data", "passes_" + n + ".csv");
        try (BufferedWriter w = Files.newBufferedWriter(p)) {
            for (int i = 1; i <= n; i++) {
                w.write(String.join(",", String.format("P%06d", i), String.format("19%07d", i), "Student" + i, String.valueOf(i % 40 + 1), "4500.0"));
                w.newLine();
            }
        }
        return p;
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Paths.get("data"));
        int[] ns = {1000, 5000, 10000, 50000, 100000};
        // warm-up
        Path wp = build(10000); PassStore ws = new PassStore(wp); for (int i = 0; i < 300; i++) ws.find("P010000");   // JIT warm-up
        System.out.println("--- B1.4  Text file, find LAST record (worst case), average of many runs ---");
        System.out.println("   n records | file size (KB) | avg find time (ms) | time per record (us)");
        for (int n : ns) {
            Path p = build(n); PassStore s = new PassStore(p); String id = String.format("P%06d", n);
            int runs = Math.max(20, 2000000 / n); for (int r = 0; r < 5; r++) s.find(id);
            long t = System.nanoTime(); for (int r = 0; r < runs; r++) s.find(id);
            double ms = (System.nanoTime() - t) / (double) runs / 1e6;
            System.out.printf("%,12d | %14.1f | %18.3f | %20.4f%n", n, Files.size(p) / 1024.0, ms, ms * 1000 / n);
        }

        System.out.println("\n--- Alternative A1: RandomAccessFile, fixed-length records (seek i x " + REC + ") ---");
        Path rp = Paths.get("data", "passes_fixed_100000.dat");
        int n = 100000;
        try (RandomAccessFile raf = new RandomAccessFile(rp.toFile(), "rw")) {
            raf.setLength(0);
            for (int i = 1; i <= n; i++) {
                byte[] rec = new byte[REC]; Arrays.fill(rec, (byte) ' ');
                byte[] txt = String.join("|", String.format("P%06d", i), String.format("19%07d", i), "Student" + i, String.valueOf(i % 40 + 1), "4500.0").getBytes();
                System.arraycopy(txt, 0, rec, 0, Math.min(txt.length, REC - 1)); rec[REC - 1] = '\n';
                raf.write(rec);
            }
        }
        try (RandomAccessFile raf = new RandomAccessFile(rp.toFile(), "r")) {
            int idx = n - 1; byte[] rec = new byte[REC];
            for (int w = 0; w < 1000; w++) { raf.seek((long) idx * REC); raf.readFully(rec); }
            long t = System.nanoTime(); for (int r = 0; r < 10000; r++) { raf.seek((long) idx * REC); raf.readFully(rec); }
            double us = (System.nanoTime() - t) / 10000 / 1e3;
            System.out.printf("seek+read of record #%,d : %.3f us (constant, independent of n)%n", n, us);
            System.out.printf("fixed file size = %,d bytes; text file size = %,d bytes; average text record = %.1f bytes -> padding wasted = %.1f bytes/record (%.0f%%)%n",
                    Files.size(rp), Files.size(Paths.get("data", "passes_100000.csv")), Files.size(Paths.get("data", "passes_100000.csv")) / (double) n,
                    REC - Files.size(Paths.get("data", "passes_100000.csv")) / (double) n,
                    100.0 * (Files.size(rp) - Files.size(Paths.get("data", "passes_100000.csv"))) / Files.size(rp));
        }

        System.out.println("\n--- Alternative B1: load once into HashMap<String,String[]>, q = 1,000 searches on n = 100,000 ---");
        Path p = Paths.get("data", "passes_100000.csv"); PassStore s = new PassStore(p);
        Random rnd = new Random(1); int q = 1000; String[] ids = new String[q];
        for (int i = 0; i < q; i++) ids[i] = String.format("P%06d", rnd.nextInt(n) + 1);
        long t0 = System.nanoTime(); for (String id : ids) s.find(id); double scanMs = (System.nanoTime() - t0) / 1e6;
        Runtime rt = Runtime.getRuntime(); System.gc(); long m0 = rt.totalMemory() - rt.freeMemory();
        t0 = System.nanoTime(); Map<String, String[]> map = new HashMap<>();
        try (BufferedReader br = Files.newBufferedReader(p)) { String l; while ((l = br.readLine()) != null) { String[] f = l.split(",", -1); if (f.length == 5) map.put(f[0], f); } }
        double loadMs = (System.nanoTime() - t0) / 1e6;
        t0 = System.nanoTime(); for (String id : ids) map.get(id); double lookMs = (System.nanoTime() - t0) / 1e6;
        System.gc(); long m1 = rt.totalMemory() - rt.freeMemory();
        System.out.printf("Scan every time  : %.1f ms for %d searches  (O(q x n))   memory = O(buffer) ~ 8 KB%n", scanMs, q);
        System.out.printf("HashMap          : load %.1f ms + %.3f ms for %d lookups = %.1f ms  (O(n + q))   extra heap ~ %.1f MB%n", loadMs, lookMs, q, loadMs + lookMs, (m1 - m0) / 1048576.0);
    }
}
