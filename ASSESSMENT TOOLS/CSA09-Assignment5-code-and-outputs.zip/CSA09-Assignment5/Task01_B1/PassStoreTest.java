import java.nio.file.*;
import java.util.*;

/** B1.1 - test add / find / list with a normal case, a missing ID and a damaged line. */
public class PassStoreTest {
    static int pass = 0, total = 0;
    static void check(String name, boolean ok, String detail) {
        total++; if (ok) pass++;
        System.out.printf("%-34s %s   %s%n", name, ok ? "PASS" : "FAIL", detail);
    }
    public static void main(String[] args) throws Exception {
        Path f = Files.createTempFile("bus_pass_test", ".csv");
        PassStore s = new PassStore(f);
        s.add("P1001", "192311001", "Arun", 12, 4500);
        s.add("P1002", "192311002", "Meena", 7, 3800);
        Files.writeString(f, "P1003,DAMAGED LINE\n", StandardOpenOption.APPEND);   // damaged: 2 fields
        s.add("P1004", "192311004", "Divya", 12, 4200);
        s.addSafe("P1005", "192311005", "Kumar, A", 7, 3900);                      // name contains the delimiter

        System.out.println("File content:");
        for (String l : Files.readAllLines(f)) System.out.println("   " + l);
        System.out.println();

        String[] r1 = s.find("P1004");
        check("T1 add + find (normal)", r1 != null && r1[2].equals("Divya"), Arrays.toString(r1));
        String[] r2 = s.find("P9999");
        check("T2 find non-existent ID", r2 == null, String.valueOf(r2 == null ? "null (not found)" : Arrays.toString(r2)));
        String[] r3 = s.find("P1003");
        check("T3 find damaged record", r3 == null, "null (damaged line skipped, no crash)");
        String[] r4 = s.find("P1004");
        check("T4 record AFTER damaged line", r4 != null, "still found -> damaged line did not stop scan");
        List<String[]> l12 = s.listByRoute(12);
        check("T5 list route 12", l12.size() == 2, l12.size() + " passes: " + l12.stream().map(x -> x[0]).toList());
        List<String[]> l7 = s.listByRoute(7);
        check("T6 list route 7 (comma in name)", l7.size() == 2 && l7.get(1)[2].equals("Kumar, A"),
              l7.size() + " passes, name decoded -> \"" + l7.get(1)[2] + "\"");
        check("T7 damaged lines counted", s.damagedSkipped == 1, "damagedSkipped = " + s.damagedSkipped);
        System.out.println("\nResult: " + pass + " / " + total + " tests passed");
        Files.delete(f);
    }
}
