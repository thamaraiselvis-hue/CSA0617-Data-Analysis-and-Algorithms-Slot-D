import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PassStore {
    private final Path file;
    /** number of damaged lines skipped during the most recent scan */
    public int damagedSkipped = 0;

    PassStore(Path file) { this.file = file; }

    public void add(String passId, String regNo, String name, int route, double amount) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(file, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(String.join(",", passId, regNo, name,
                    String.valueOf(route), String.valueOf(amount)));
            w.newLine();
        }
    }

    /** Returns the five fields of the pass with the given ID, or null if not found. */
    public String[] find(String passId) throws IOException {
        // TODO 1 (completed): read line by line with a BufferedReader inside try-with-resources;
        // skip damaged lines (not exactly 5 fields); return the fields of the matching pass
        try (BufferedReader br = Files.newBufferedReader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] f = line.split(",", -1);       // -1 keeps trailing empty fields
                if (f.length != 5) continue;            // damaged line -> skip, keep searching
                if (f[0].equals(passId)) return f;      // match found
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Extra methods used by Tasks B1 / B2 (not part of the given program)
    // ------------------------------------------------------------------

    /** Strict parser: exactly 5 fields, non-empty ID, int route, numeric amount. Returns null if damaged. */
    static String[] parseStrict(String line) {
        if (line == null || line.isBlank()) return null;
        String[] f = line.split(",", -1);
        if (f.length != 5 || f[0].isBlank()) return null;
        try { Integer.parseInt(f[3]); Double.parseDouble(f[4]); } catch (NumberFormatException e) { return null; }
        for (int i = 0; i < 5; i++) f[i] = decode(f[i]);
        return f;
    }

    /** Like find(), but also rejects lines whose route/amount are not numbers. Counts skipped lines. */
    public String[] findValidated(String passId) throws IOException {
        damagedSkipped = 0;
        try (BufferedReader br = Files.newBufferedReader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] f = parseStrict(line);
                if (f == null) { damagedSkipped++; continue; }
                if (f[0].equals(passId)) return f;
            }
        }
        return null;
    }

    /** (iii) list all passes on a given route (strict parser, damaged lines skipped). */
    public List<String[]> listByRoute(int route) throws IOException {
        damagedSkipped = 0;
        List<String[]> out = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] f = parseStrict(line);
                if (f == null) { damagedSkipped++; continue; }
                if (Integer.parseInt(f[3]) == route) out.add(f);
            }
        }
        return out;
    }

    /** add() that protects the delimiter: ',' -> %2C and '%' -> %25 inside every field. */
    public void addSafe(String passId, String regNo, String name, int route, double amount) throws IOException {
        add(encode(passId), encode(regNo), encode(name), route, amount);
    }
    static String encode(String s) { return s.replace("%", "%25").replace(",", "%2C").replace("\n", "%0A"); }
    static String decode(String s) { return s.replace("%2C", ",").replace("%0A", "\n").replace("%25", "%"); }

    public static void main(String[] args) throws IOException {
        Path f = Files.createTempFile("passes", ".csv");
        PassStore store = new PassStore(f);
        store.add("P1001", "192311001", "Arun", 12, 4500);
        Files.writeString(f, "P1002,DAMAGED LINE\n", StandardOpenOption.APPEND);
        store.add("P1003", "192311003", "Divya", 7, 3800);
        System.out.println(Arrays.toString(store.find("P1003")));
        System.out.println(Arrays.toString(store.find("P1002")));
        Files.delete(f);
    }
}
