-- Local TEST database created only for CSA09 Assignment 5
DROP DATABASE IF EXISTS transport_test;
CREATE DATABASE transport_test CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'pass_user'@'localhost' IDENTIFIED BY 'pass@123';
GRANT ALL PRIVILEGES ON transport_test.* TO 'pass_user'@'localhost';
FLUSH PRIVILEGES;
USE transport_test;

CREATE TABLE bus_pass (
  pass_id  VARCHAR(10)  NOT NULL,
  reg_no   VARCHAR(12)  NOT NULL,
  name     VARCHAR(60)  NOT NULL,
  route_no INT          NOT NULL,
  amount   DOUBLE       NOT NULL,
  PRIMARY KEY (pass_id)
) ENGINE=InnoDB;

CREATE TABLE users (
  id  VARCHAR(20) NOT NULL,
  pwd VARCHAR(40) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;
INSERT INTO users VALUES ('admin','Secret@123'),('arun','arun#2026');

CREATE TABLE hostel_wallet  (student_id VARCHAR(10) PRIMARY KEY, balance DECIMAL(10,2) NOT NULL) ENGINE=InnoDB;
CREATE TABLE canteen_wallet (student_id VARCHAR(10) PRIMARY KEY, balance DECIMAL(10,2) NOT NULL) ENGINE=InnoDB;
INSERT INTO hostel_wallet  VALUES ('S1', 2000.00);
INSERT INTO canteen_wallet VALUES ('S1',  300.00);
