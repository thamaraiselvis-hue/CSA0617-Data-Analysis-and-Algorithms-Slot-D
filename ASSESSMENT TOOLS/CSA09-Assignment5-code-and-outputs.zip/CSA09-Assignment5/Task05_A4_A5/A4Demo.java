import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** A4 - what should be serialized? transient fields, object graph, and serialization vs CSV vs JSON. */
public class A4Demo {
    static class Resident implements Serializable {
        private static final long serialVersionUID = 1L;
        String name, regNo;
        transient String password;          // secret -> never written to disk
        transient Connection con;           // live resource -> cannot be serialized, must be re-opened after load
        Resident(String n, String r, String p) { name = n; regNo = r; password = p; }
    }
    static class Room implements Serializable {
        private static final long serialVersionUID = 1L;
        int no; List<Resident> residents = new ArrayList<>();
        Room(int no) { this.no = no; }
    }
    static class Hostel implements Serializable {
        private static final long serialVersionUID = 1L;
        String name; List<Room> rooms = new ArrayList<>();
        Hostel(String n) { name = n; }
    }
    // BAD design: Connection is NOT transient
    static class BadResident implements Serializable { String name; String regNo; Connection con; }
    static class BadHostel implements Serializable { List<BadResident> list = new ArrayList<>(); }

    public static void main(String[] args) throws Exception {
        System.out.println("=== A4.1  Object graph and transient fields ===");
        try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost:3306/transport_test", "pass_user", "pass@123")) {
            // (a) what happens if the Connection field is NOT transient
            BadHostel bh = new BadHostel(); BadResident br = new BadResident(); br.name = "Arun"; br.regNo = "192311001"; br.con = con; bh.list.add(br);
            try (ObjectOutputStream o = new ObjectOutputStream(new ByteArrayOutputStream())) { o.writeObject(bh); }
            catch (NotSerializableException e) { System.out.println("(a) Connection field NOT transient -> java.io.NotSerializableException: " + e.getMessage().replaceAll("^.*\\.", "")); }

            // (b) correct design
            Hostel h = new Hostel("Kaveri Hostel");
            Resident shared = null;
            for (int r = 1; r <= 3; r++) { Room room = new Room(100 + r);
                for (int k = 1; k <= 2; k++) { Resident x = new Resident("Student" + r + k, "19231" + r + "00" + k, "secret" + r + k); x.con = con; room.residents.add(x); if (r == 1 && k == 1) shared = x; }
                h.rooms.add(room); }
            h.rooms.get(2).residents.add(shared);       // the SAME Resident object referenced from two rooms
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (ObjectOutputStream o = new ObjectOutputStream(bos)) { o.writeObject(h); }
            System.out.println("(b) Hostel -> 3 Rooms -> 7 resident references (6 distinct objects) serialized with ONE writeObject(hostel): " + bos.size() + " bytes");
            Hostel back;
            try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()))) { back = (Hostel) in.readObject(); }
            Resident r0 = back.rooms.get(0).residents.get(0);
            System.out.println("    after readObject: hostel=" + back.name + ", rooms=" + back.rooms.size() + ", first resident=" + r0.name + "/" + r0.regNo);
            System.out.println("    password (transient) = " + r0.password + " ,  con (transient) = " + r0.con + "   -> not stored, must be re-created");
            Resident again = back.rooms.get(2).residents.get(2);
            System.out.println("    shared resident still ONE object after reload? same reference = " + (again == r0));
        }

        System.out.println("\n=== A4 Alternative  Serialization vs CSV vs JSON (n residents; time = average of 3 runs after warm-up, ms) ===");
        System.out.println("         n | format        | size (KB) | save ms | load ms");
        for (int n : new int[]{1000, 10000, 100000}) {
            List<Resident> list = new ArrayList<>(n);
            for (int i = 1; i <= n; i++) list.add(new Resident("Student" + i, String.format("19%07d", i), "pw" + i));
            for (int w = 0; w < 2; w++) { Path wp = Files.createTempFile("w", ".bin"); serSave(wp, list); serLoad(wp); csvSave(wp, list); csvLoad(wp); jsonSave(wp, list); jsonLoad(wp); Files.delete(wp); }
            for (String fmt : new String[]{"Serialization", "CSV", "JSON"}) {
                Path p = Files.createTempFile("res", ".dat"); double sv = 0, ld = 0;
                for (int r = 0; r < 3; r++) {
                    long t = System.nanoTime();
                    if (fmt.equals("Serialization")) serSave(p, list); else if (fmt.equals("CSV")) csvSave(p, list); else jsonSave(p, list);
                    sv += (System.nanoTime() - t) / 1e6; t = System.nanoTime();
                    int cnt = fmt.equals("Serialization") ? serLoad(p) : fmt.equals("CSV") ? csvLoad(p) : jsonLoad(p);
                    ld += (System.nanoTime() - t) / 1e6; if (cnt != n) throw new IllegalStateException(fmt + " lost data");
                }
                System.out.printf("%,10d | %-13s | %9.1f | %7.1f | %7.1f%n", n, fmt, Files.size(p) / 1024.0, sv / 3, ld / 3);
                Files.delete(p);
            }
        }
    }
    static void serSave(Path p, List<Resident> l) throws IOException { try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(p)))) { o.writeObject(new ArrayList<>(l)); } }
    @SuppressWarnings("unchecked") static int serLoad(Path p) throws Exception { try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(p)))) { return ((List<Resident>) in.readObject()).size(); } }
    static void csvSave(Path p, List<Resident> l) throws IOException { try (BufferedWriter w = Files.newBufferedWriter(p)) { for (Resident r : l) { w.write(r.name + "," + r.regNo); w.newLine(); } } }
    static int csvLoad(Path p) throws IOException { int n = 0; try (BufferedReader br = Files.newBufferedReader(p)) { String s; while ((s = br.readLine()) != null) { String[] f = s.split(","); new Resident(f[0], f[1], null); n++; } } return n; }
    static void jsonSave(Path p, List<Resident> l) throws IOException { try (BufferedWriter w = Files.newBufferedWriter(p)) { w.write("[\n"); for (int i = 0; i < l.size(); i++) { Resident r = l.get(i); w.write("  {\"name\":\"" + r.name + "\",\"regNo\":\"" + r.regNo + "\"}" + (i < l.size() - 1 ? ",\n" : "\n")); } w.write("]\n"); } }
    static int jsonLoad(Path p) throws IOException { int n = 0; try (BufferedReader br = Files.newBufferedReader(p)) { String s; while ((s = br.readLine()) != null) { int a = s.indexOf("\"name\":\""); if (a < 0) continue; a += 8; int b = s.indexOf('"', a); String nm = s.substring(a, b); a = s.indexOf("\"regNo\":\"") + 9; b = s.indexOf('"', a); new Resident(nm, s.substring(a, b), null); n++; } } return n; }
}
