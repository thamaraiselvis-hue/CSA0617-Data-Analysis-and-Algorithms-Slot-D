import java.io.*;
public class Reader { public static void main(String[] a) throws Exception {
  try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(a[0]))) { System.out.println("Version 2 read OLD file: " + in.readObject()); }
  catch (InvalidClassException e) { System.out.println("Version 2 read OLD file: FAILED -> java.io.InvalidClassException: " + e.getMessage().replaceAll("^Resident; ", "Resident; ")); } } }
