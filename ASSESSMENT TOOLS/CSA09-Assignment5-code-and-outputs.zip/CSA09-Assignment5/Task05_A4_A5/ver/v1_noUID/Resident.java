import java.io.Serializable;
public class Resident implements Serializable {

    String name, regNo;

    Resident(String n, String r) { name = n; regNo = r; }
    public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + "" + "]"; }
}
