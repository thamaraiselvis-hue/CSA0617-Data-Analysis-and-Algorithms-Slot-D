import java.io.*;
public class Writer { public static void main(String[] a) throws Exception {
  try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(a[0]))) { o.writeObject(new Resident("Arun", "192311001")); }
  System.out.println("Version 1 saved: " + new Resident("Arun", "192311001") + " -> " + a[0]); } }
