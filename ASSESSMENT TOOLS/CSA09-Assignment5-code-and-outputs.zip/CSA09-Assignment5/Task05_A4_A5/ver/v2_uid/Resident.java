import java.io.Serializable;
public class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    String name, regNo;
    String phone;
    Resident(String n, String r) { name = n; regNo = r; }
    public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + ", phone=" + phone + "]"; }
}
