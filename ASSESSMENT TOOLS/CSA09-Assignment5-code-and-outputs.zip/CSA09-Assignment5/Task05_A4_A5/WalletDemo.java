import java.sql.*;

/** A5 - transfer Rs.500 hostel wallet -> canteen wallet: two auto-commit updates vs ONE transaction. */
public class WalletDemo {
    static final String URL = "jdbc:mariadb://localhost:3306/transport_test";

    static void reset(Connection c) throws SQLException {
        try (Statement s = c.createStatement()) {
            s.executeUpdate("UPDATE hostel_wallet SET balance = 2000 WHERE student_id='S1'");
            s.executeUpdate("UPDATE canteen_wallet SET balance = 300 WHERE student_id='S1'");
        }
    }
    static void show(Connection c, String label) throws SQLException {
        try (Statement s = c.createStatement()) {
            double h, k;
            try (ResultSet r = s.executeQuery("SELECT balance FROM hostel_wallet WHERE student_id='S1'")) { r.next(); h = r.getDouble(1); }
            try (ResultSet r = s.executeQuery("SELECT balance FROM canteen_wallet WHERE student_id='S1'")) { r.next(); k = r.getDouble(1); }
            System.out.printf("   %-34s hostel = %7.2f   canteen = %7.2f   TOTAL = %7.2f%n", label, h, k, h + k);
        }
    }

    /** two independent auto-commit statements */
    static void transferAutoCommit(Connection c, boolean crash) throws SQLException {
        try (Statement s = c.createStatement()) {
            s.executeUpdate("UPDATE hostel_wallet SET balance = balance - 500 WHERE student_id='S1'");    // committed immediately
            if (crash) throw new IllegalStateException("simulated power failure between the two updates");
            s.executeUpdate("UPDATE canteen_wallet SET balance = balance + 500 WHERE student_id='S1'");
        }
    }
    /** one transaction: commit on success, rollback on any failure */
    static void transferTx(Connection c, boolean crash) throws SQLException {
        boolean old = c.getAutoCommit();
        c.setAutoCommit(false);
        try (PreparedStatement debit = c.prepareStatement("UPDATE hostel_wallet SET balance = balance - ? WHERE student_id = ?");
             PreparedStatement credit = c.prepareStatement("UPDATE canteen_wallet SET balance = balance + ? WHERE student_id = ?")) {
            debit.setBigDecimal(1, new java.math.BigDecimal("500")); debit.setString(2, "S1"); debit.executeUpdate();
            if (crash) throw new IllegalStateException("simulated power failure between the two updates");
            credit.setBigDecimal(1, new java.math.BigDecimal("500")); credit.setString(2, "S1"); credit.executeUpdate();
            c.commit();
        } catch (SQLException | RuntimeException e) { c.rollback(); throw e; }
        finally { c.setAutoCommit(old); }
    }

    public static void main(String[] args) throws Exception {
        try (Connection c = DriverManager.getConnection(URL, "pass_user", "pass@123")) {
            reset(c); System.out.println("Start state:"); show(c, "initial");
            System.out.println("\n--- Case 1: two AUTO-COMMIT updates, failure between them ---");
            try { transferAutoCommit(c, true); } catch (IllegalStateException e) { System.out.println("   exception: " + e.getMessage()); }
            show(c, "after failure (auto-commit)");
            reset(c);
            System.out.println("\n--- Case 2: ONE TRANSACTION (commit / rollback), failure between the updates ---");
            try { transferTx(c, true); } catch (IllegalStateException e) { System.out.println("   exception: " + e.getMessage() + "  -> rollback() executed"); }
            show(c, "after failure (transaction)");
            System.out.println("\n--- Case 3: ONE TRANSACTION, no failure ---");
            transferTx(c, false); show(c, "after success (transaction)");
            reset(c);

            System.out.println("\n--- Time cost: 2,000 transfers ---");
            int N = 2000; for (int w = 0; w < 200; w++) transferTx(c, false);
            reset(c); long t = System.nanoTime(); for (int i = 0; i < N; i++) transferAutoCommit(c, false); double a = (System.nanoTime() - t) / 1e6;
            reset(c); t = System.nanoTime(); for (int i = 0; i < N; i++) transferTx(c, false); double b = (System.nanoTime() - t) / 1e6;
            System.out.printf("   two auto-commit updates : %.0f ms total  (%.3f ms per transfer, 2 commits)%n", a, a / N);
            System.out.printf("   one transaction         : %.0f ms total  (%.3f ms per transfer, 1 commit)%n", b, b / N);
            reset(c);
        }
    }
}
