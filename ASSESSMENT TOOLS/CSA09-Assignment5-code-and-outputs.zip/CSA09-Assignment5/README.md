# CSA09 – Programming in Java – Assignment 5 (CO5)
Data Persistence Engineering – Files and Databases

- **Name:** ____________________   **Register number:** ____________________
- **Java version:** OpenJDK 21   **Database:** MySQL / MariaDB 10.11 (test DB `transport_test`)   **Driver:** MariaDB Connector/J 2.7.6

## Setup
1. Run `sql/schema.sql` in MySQL/MariaDB (creates test DB, user `pass_user` / `pass@123`, tables).
2. Put the JDBC driver jar (`mariadb-java-client.jar` or MySQL Connector/J) on the class path (change the URL in the code if you use MySQL: `jdbc:mysql://localhost:3306/transport_test`).
3. Compile per task: `javac -cp mariadb-java-client.jar -d out *.java` and run with `java -cp out:mariadb-java-client.jar <Class>` (use `;` on Windows).

## Tasks
| Folder | Programs | Result |
|---|---|---|
| Task01_B1 | PassStore (TODO 1), PassStoreTest, LineCounter, GrowthBench, MemCheck | find skips damaged lines; 7/7 tests pass; buffering 346x faster at 50 MB; find time grows linearly |
| Task02_B2 | LoginDemo, DamagedFileDemo, ValidationCost | injection accepted by unsafe login, rejected by PreparedStatement; damaged file handled |
| Task03_B3 | PassLoader (TODO 1-3), B3Bench, B3TxCompare, AltInsert | auto-commit vs transaction; failure leaves 5,000 vs 0 rows |
| Task04_B4 | MakeOldFile, Migrate, DbInfo, Scale, ConcurrencyDemo | 20,001 loaded + 7 rejected; DB lookup 0.059 ms; file store lost 724/1000 passes |
| Task05_A4_A5 | A4Demo, WalletDemo, ver/ (serialVersionUID experiment) | transient/graph, versioning, transaction vs auto-commit |

`output_*.txt` in each folder = captured program output; `screens/` = screenshots used in the report.
Commit each task separately (at least one commit per task).
