import java.sql.*;
import java.util.*;

/** B3 - Statement vs PreparedStatement vs Batch; auto-commit vs transaction; forced failure. */
public class B3Bench {
    static final String URL = "jdbc:mariadb://localhost:3306/transport_test";

    static List<String[]> gen(int n) {
        List<String[]> l = new ArrayList<>(n);
        for (int i = 1; i <= n; i++)
            l.add(new String[]{String.format("P%06d", i), String.format("19%07d", i), "Student" + i, String.valueOf(i % 40 + 1), "4500.0"});
        return l;
    }
    static void truncate(Connection c) throws SQLException { try (Statement s = c.createStatement()) { s.execute("TRUNCATE TABLE bus_pass"); } }
    static long count(Connection c) throws SQLException { try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM bus_pass")) { r.next(); return r.getLong(1); } }

    // (a) plain Statement: one SQL string per row, auto-commit ON
    static void viaStatement(Connection c, List<String[]> p) throws SQLException {
        try (Statement st = c.createStatement()) {
            for (String[] r : p)
                st.executeUpdate("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES ('" + r[0] + "','" + r[1] + "','" + r[2] + "'," + r[3] + "," + r[4] + ")");
        }
    }
    // (b) PreparedStatement: one execute per row, auto-commit ON
    static void viaPrepared(Connection c, List<String[]> p) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES (?,?,?,?,?)")) {
            for (String[] r : p) { bind(ps, r); ps.executeUpdate(); }
        }
    }
    // (c) PreparedStatement + addBatch/executeBatch (1,000 per batch), auto-commit ON
    static void viaBatch(Connection c, List<String[]> p) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES (?,?,?,?,?)")) {
            int n = 0;
            for (String[] r : p) { bind(ps, r); ps.addBatch(); if (++n % 1000 == 0) ps.executeBatch(); }
            ps.executeBatch();
        }
    }
    static void bind(PreparedStatement ps, String[] r) throws SQLException {
        ps.setString(1, r[0]); ps.setString(2, r[1]); ps.setString(3, r[2]); ps.setInt(4, Integer.parseInt(r[3])); ps.setDouble(5, Double.parseDouble(r[4]));
    }

    interface Job { void run(Connection c, List<String[]> p) throws SQLException; }
    static double time(Connection c, Job j, List<String[]> p) throws SQLException {
        truncate(c); long t = System.nanoTime(); j.run(c, p); return (System.nanoTime() - t) / 1e6;
    }

    static void metadata(Connection c) throws SQLException {
        try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT * FROM bus_pass ORDER BY pass_id LIMIT 3")) {
            ResultSetMetaData md = r.getMetaData();
            System.out.println("    ResultSetMetaData: " + md.getColumnCount() + " columns");
            for (int i = 1; i <= md.getColumnCount(); i++)
                System.out.printf("      col %d  %-9s  SQL type = %-8s  Java class = %s%n", i, md.getColumnName(i), md.getColumnTypeName(i), md.getColumnClassName(i));
            while (r.next()) System.out.printf("      row: %s | %s | %s | %d | %.1f%n", r.getString(1), r.getString(2), r.getString(3), r.getInt(4), r.getDouble(5));
        }
    }

    public static void main(String[] args) throws Exception {
        try (Connection c = DriverManager.getConnection(URL, "pass_user", "pass@123")) {
            System.out.println("=== B3.1  Correctness on small data (10 records per approach) ===");
            String[] names = {"Statement", "PreparedStatement", "PreparedStatement + Batch"};
            Job[] jobs = {B3Bench::viaStatement, B3Bench::viaPrepared, B3Bench::viaBatch};
            List<String[]> ten = gen(10);
            for (int k = 0; k < 3; k++) {
                truncate(c); jobs[k].run(c, ten);
                System.out.println("  [" + names[k] + "]  rows in table = " + count(c) + "  (expected 10)");
                if (k == 0 || k == 2) metadata(c);
            }

            System.out.println("\n=== B3.2  Increase the data size (auto-commit ON, time in ms) ===");
            for (int k = 0; k < 3; k++) { truncate(c); jobs[k].run(c, gen(500)); }          // warm-up
            System.out.println("      rows | Statement | PreparedStatement | PreparedStatement+Batch");
            int[] sizes = {1000, 10000, 100000};
            for (int n : sizes) {
                List<String[]> p = gen(n);
                double a = time(c, B3Bench::viaStatement, p), b = time(c, B3Bench::viaPrepared, p), d = time(c, B3Bench::viaBatch, p);
                System.out.printf("%,10d | %,9.0f | %,17.0f | %,23.0f%n", n, a, b, d);
                System.out.flush();
            }

            System.out.println("\n=== B3.3  Auto-commit vs single transaction (batch insert, time in ms) ===");
            System.out.println("      rows | batch, auto-commit ON | batch, ONE transaction (PassLoader.loadAll)");
            for (int n : sizes) {
                List<String[]> p = gen(n);
                double auto = time(c, B3Bench::viaBatch, p);
                double tx = time(c, (cc, pp) -> PassLoader.loadAll(cc, pp), p);
                System.out.printf("%,10d | %,21.0f | %,24.0f   (rows loaded = %,d)%n", n, auto, tx, count(c));
            }

            System.out.println("\n--- Forced failure half-way: 10,000 passes, row #5,500 has amount = 'FORTY-FIVE' ---");
            List<String[]> bad = gen(10000); bad.get(5499)[4] = "FORTY-FIVE";
            truncate(c);
            try { viaBatch(c, bad); } catch (Exception e) { System.out.println("  auto-commit run   -> exception: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
            System.out.println("  auto-commit run   -> rows left in table = " + count(c) + "   (partial data stays!)");
            truncate(c);
            try { PassLoader.loadAll(c, bad); } catch (Exception e) { System.out.println("  transaction run   -> exception: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
            System.out.println("  transaction run   -> rows left in table = " + count(c) + "   (rollback removed every insert)");
            truncate(c);
            int ok = PassLoader.loadAll(c, gen(10000));
            System.out.println("  sanity: same list without the bad row -> loadAll returned " + ok + ", rows in table = " + count(c));
        }
    }
}
