import java.sql.*;
import java.util.*;

/** B3.2 (extra) - the same three approaches, but each run inside ONE transaction, to separate commit cost from statement cost. */
public class B3TxCompare {
    public static void main(String[] args) throws Exception {
        try (Connection c = DriverManager.getConnection(B3Bench.URL, "pass_user", "pass@123")) {
            B3Bench.Job[] jobs = {B3Bench::viaStatement, B3Bench::viaPrepared, B3Bench::viaBatch};
            c.setAutoCommit(false);
            for (B3Bench.Job j : jobs) { B3Bench.truncate(c); j.run(c, B3Bench.gen(500)); c.commit(); }   // warm-up
            System.out.println("All three approaches inside ONE transaction (auto-commit OFF, single commit at the end), time in ms");
            System.out.println("      rows | Statement | PreparedStatement | PreparedStatement+Batch");
            for (int n : new int[]{1000, 10000, 100000}) {
                List<String[]> p = B3Bench.gen(n); double[] t = new double[3];
                for (int k = 0; k < 3; k++) {
                    B3Bench.truncate(c); c.commit();
                    long s = System.nanoTime(); jobs[k].run(c, p); c.commit(); t[k] = (System.nanoTime() - s) / 1e6;
                    if (B3Bench.count(c) != n) throw new IllegalStateException("row count mismatch");
                }
                System.out.printf("%,10d | %,9.0f | %,17.0f | %,23.0f%n", n, t[0], t[1], t[2]);
            }
        }
    }
}
