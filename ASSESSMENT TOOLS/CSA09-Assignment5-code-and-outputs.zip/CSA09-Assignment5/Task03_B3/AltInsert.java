import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B3 Alternative - multi-row INSERT and LOAD DATA LOCAL INFILE compared with PreparedStatement batch. */
public class AltInsert {
    public static void main(String[] args) throws Exception {
        String url = "jdbc:mariadb://localhost:3306/transport_test?allowLocalInfile=true";
        int[] sizes = {1000, 10000, 100000};
        try (Connection c = DriverManager.getConnection(url, "pass_user", "pass@123")) {
            System.out.println("      rows | PS batch (tx) | multi-row INSERT b=1000 | LOAD DATA | longest multi-row SQL");
            for (int n : sizes) {
                List<String[]> p = B3Bench.gen(n);
                B3Bench.truncate(c);
                long t = System.nanoTime(); PassLoader.loadAll(c, p); double ps = (System.nanoTime() - t) / 1e6;

                B3Bench.truncate(c); c.setAutoCommit(false);
                t = System.nanoTime(); int maxLen = 0;
                for (int i = 0; i < n; i += 1000) {
                    StringBuilder sb = new StringBuilder("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES ");
                    for (int j = i; j < Math.min(n, i + 1000); j++) { String[] r = p.get(j); if (j > i) sb.append(',');
                        sb.append("('").append(r[0]).append("','").append(r[1]).append("','").append(r[2]).append("',").append(r[3]).append(',').append(r[4]).append(')'); }
                    maxLen = Math.max(maxLen, sb.length());
                    try (Statement st = c.createStatement()) { st.executeUpdate(sb.toString()); }
                }
                c.commit(); c.setAutoCommit(true);
                double multi = (System.nanoTime() - t) / 1e6; long rowsMulti = B3Bench.count(c);

                Path csv = Paths.get("data_" + n + ".csv").toAbsolutePath();
                try (BufferedWriter w = Files.newBufferedWriter(csv)) { for (String[] r : p) { w.write(String.join(",", r)); w.newLine(); } }
                B3Bench.truncate(c);
                t = System.nanoTime();
                try (Statement st = c.createStatement()) {
                    st.execute("LOAD DATA LOCAL INFILE '" + csv.toString().replace("\\", "/") + "' INTO TABLE bus_pass FIELDS TERMINATED BY ',' LINES TERMINATED BY '\\n' (pass_id,reg_no,name,route_no,amount)");
                }
                double load = (System.nanoTime() - t) / 1e6; long rowsLoad = B3Bench.count(c);
                Files.delete(csv);
                System.out.printf("%,10d | %,13.0f | %,23.0f | %,9.0f | %,d chars (%d KB)%n", n, ps, multi, load, maxLen, maxLen / 1024);
                if (rowsMulti != n || rowsLoad != n) System.out.println("ROW COUNT MISMATCH");
            }
        }
    }
}
