import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B4.3 evidence + B4 Alternative: 12 campuses x ~66,667 passes (about 100x today's 8,000/yr = 800,000).
 *  Compare (a) one serialized file per campus: search ALL campuses, and (b) one shared database with a primary key. */
public class Scale {
    static class Pass implements Serializable {
        private static final long serialVersionUID = 1L;
        String passId, regNo, name; int route; double amount;
        Pass(String p, String r, String n, int rt, double a) { passId = p; regNo = r; name = n; route = rt; amount = a; }
    }
    public static void main(String[] args) throws Exception {
        int campuses = 12, per = 66667;
        Files.createDirectories(Paths.get("campus"));
        System.out.println("Total passes simulated: " + (long) campuses * per);
        // ---- (a) one serialized file per campus
        long t = System.nanoTime(); long bytes = 0;
        for (int c = 0; c < campuses; c++) {
            ArrayList<Pass> l = new ArrayList<>(per);
            for (int i = 0; i < per; i++) { int id = c * per + i + 1; l.add(new Pass(String.format("P%07d", id), String.format("19%07d", id), "Student" + id, id % 40 + 1, 4500.0)); }
            Path f = Paths.get("campus", "campus" + (c + 1) + ".ser");
            try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(f)))) { o.writeObject(l); }
            bytes += Files.size(f);
        }
        double saveMs = (System.nanoTime() - t) / 1e6;
        System.out.printf("(a) 12 serialized files: total %.1f MB, written in %.0f ms%n", bytes / 1048576.0, saveMs);
        String target = String.format("P%07d", campuses * per);        // last pass of the last campus = worst case
        t = System.nanoTime(); String found = null;
        for (int c = 0; c < campuses && found == null; c++) {
            try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(Paths.get("campus", "campus" + (c + 1) + ".ser"))))) {
                @SuppressWarnings("unchecked") ArrayList<Pass> l = (ArrayList<Pass>) in.readObject();
                for (Pass p : l) if (p.passId.equals(target)) { found = p.name; break; }
            }
        }
        double searchMs = (System.nanoTime() - t) / 1e6;
        System.out.printf("    search for %s across all 12 campus files: found '%s' in %.0f ms (must deserialize every file)%n", target, found, searchMs);

        // ---- (b) shared database
        try (Connection con = DriverManager.getConnection(Migrate.URL, "pass_user", "pass@123")) {
            try (Statement st = con.createStatement()) { st.execute("TRUNCATE TABLE bus_pass"); }
            List<String[]> all = new ArrayList<>(campuses * per);
            for (int i = 1; i <= campuses * per; i++) all.add(new String[]{String.format("P%07d", i), String.format("19%07d", i), "Student" + i, String.valueOf(i % 40 + 1), "4500.0"});
            t = System.nanoTime(); int n = PassLoader.loadAll(con, all); double loadMs = (System.nanoTime() - t) / 1e6;
            System.out.printf("(b) database: loaded %,d rows in %.0f ms (batch+transaction)%n", n, loadMs);
            try (PreparedStatement ps = con.prepareStatement("SELECT name FROM bus_pass WHERE pass_id = ?")) {
                for (int w = 0; w < 200; w++) { ps.setString(1, target); try (ResultSet r = ps.executeQuery()) { r.next(); } }
                t = System.nanoTime(); int runs = 2000; String nm = null;
                for (int w = 0; w < runs; w++) { ps.setString(1, target); try (ResultSet r = ps.executeQuery()) { r.next(); nm = r.getString(1); } }
                System.out.printf("    SELECT by primary key for %s: found '%s' in %.3f ms per query (average of %d)%n", target, nm, (System.nanoTime() - t) / 1e6 / runs, runs);
            }
            try (Statement st = con.createStatement(); ResultSet r = st.executeQuery("SELECT ROUND((data_length+index_length)/1048576,1) FROM information_schema.tables WHERE table_schema='transport_test' AND table_name='bus_pass'")) {
                r.next(); System.out.printf("    table size on disk (data + index): %s MB%n", r.getString(1));
            }
        }
        for (int c = 0; c < campuses; c++) Files.deleteIfExists(Paths.get("campus", "campus" + (c + 1) + ".ser"));
    }
}
