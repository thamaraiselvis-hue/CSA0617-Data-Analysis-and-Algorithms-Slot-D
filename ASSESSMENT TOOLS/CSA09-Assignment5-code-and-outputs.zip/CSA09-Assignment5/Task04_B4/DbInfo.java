import java.sql.*;

/** B4.2 - inspect the database with DatabaseMetaData */
public class DbInfo {
    public static void main(String[] args) throws Exception {
        try (Connection con = DriverManager.getConnection(Migrate.URL, "pass_user", "pass@123")) {
            DatabaseMetaData md = con.getMetaData();
            System.out.println("Database product name    : " + md.getDatabaseProductName());
            System.out.println("Database product version : " + md.getDatabaseProductVersion());
            System.out.println("Driver name              : " + md.getDriverName());
            System.out.println("Driver version           : " + md.getDriverVersion());
            System.out.println("JDBC version (driver)    : " + md.getJDBCMajorVersion() + "." + md.getJDBCMinorVersion());
            System.out.println("Connection URL           : " + md.getURL());
            System.out.println("Logged-in user           : " + md.getUserName());
            System.out.println("Supports transactions    : " + md.supportsTransactions());
            System.out.println("Supports batch updates   : " + md.supportsBatchUpdates());
            System.out.println("Default isolation level  : " + isolation(md.getDefaultTransactionIsolation()));
            System.out.println("Max connections (server) : " + md.getMaxConnections() + "  (0 = no fixed driver limit)");
            System.out.println("Catalog (database)       : " + con.getCatalog());
            System.out.println("\nTables present in '" + con.getCatalog() + "':");
            try (ResultSet rs = md.getTables(con.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) System.out.println("   - " + rs.getString("TABLE_NAME") + "   (" + rs.getString("TABLE_TYPE") + ")");
            }
            System.out.println("\nColumns of bus_pass:");
            try (ResultSet rs = md.getColumns(con.getCatalog(), null, "bus_pass", "%")) {
                while (rs.next()) System.out.printf("   %-9s %-8s size=%s nullable=%s%n", rs.getString("COLUMN_NAME"), rs.getString("TYPE_NAME"), rs.getString("COLUMN_SIZE"), rs.getString("IS_NULLABLE"));
            }
            try (ResultSet rs = md.getPrimaryKeys(con.getCatalog(), null, "bus_pass")) {
                while (rs.next()) System.out.println("   PRIMARY KEY column: " + rs.getString("COLUMN_NAME"));
            }
        }
    }
    static String isolation(int i) {
        switch (i) { case Connection.TRANSACTION_READ_COMMITTED: return "READ_COMMITTED";
            case Connection.TRANSACTION_REPEATABLE_READ: return "REPEATABLE_READ";
            case Connection.TRANSACTION_SERIALIZABLE: return "SERIALIZABLE";
            case Connection.TRANSACTION_READ_UNCOMMITTED: return "READ_UNCOMMITTED"; default: return "NONE"; }
    }
}
