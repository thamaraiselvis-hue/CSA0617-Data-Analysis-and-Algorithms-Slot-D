import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B4.1 - migrate the existing pass FILE into the database using batches + one transaction,
 *  validating every line first and reporting the records that failed validation. */
public class Migrate {
    static final String URL = "jdbc:mariadb://localhost:3306/transport_test";

    /** returns null if the line is valid, otherwise the reason */
    static String validate(String line, Set<String> seen, List<String[]> good) {
        if (line.isBlank()) return "empty line";
        String[] f = line.split(",", -1);
        if (f.length != 5) return "wrong field count (" + f.length + ")";
        f = Arrays.stream(f).map(PassStore::decode).toArray(String[]::new);
        if (f[0].isBlank() || f[0].length() > 10) return "pass id missing / too long";
        if (!f[1].matches("\\d{9}")) return "register number is not 9 digits";
        if (f[2].isBlank() || f[2].length() > 60) return "name missing / too long";
        try { int r = Integer.parseInt(f[3]); if (r < 1 || r > 99) return "route out of range 1-99"; }
        catch (NumberFormatException e) { return "route is not a number"; }
        try { double a = Double.parseDouble(f[4]); if (a <= 0) return "amount must be positive"; }
        catch (NumberFormatException e) { return "amount is not a number"; }
        if (!seen.add(f[0])) return "duplicate pass id " + f[0];
        good.add(f);
        return null;
    }

    public static void main(String[] args) throws Exception {
        Path src = Paths.get(args.length > 0 ? args[0] : "old_passes.csv");
        List<String[]> good = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        int lineNo = 0;
        try (BufferedReader br = Files.newBufferedReader(src)) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                String why = validate(line, seen, good);
                if (why != null) failed.add(String.format("line %-6d %-34s [%s]", lineNo, why, line.length() > 45 ? line.substring(0, 45) + "..." : line));
            }
        }
        System.out.println("Source file           : " + src + "  (" + lineNo + " lines)");
        System.out.println("Passed validation     : " + good.size());
        System.out.println("FAILED validation     : " + failed.size());
        for (String f : failed) System.out.println("   " + f);

        try (Connection con = DriverManager.getConnection(URL, "pass_user", "pass@123")) {
            try (Statement st = con.createStatement()) { st.execute("TRUNCATE TABLE bus_pass"); }
            long t = System.nanoTime();
            int loaded = PassLoader.loadAll(con, good);          // batches of 1,000 inside ONE transaction
            double ms = (System.nanoTime() - t) / 1e6;
            long inDb;
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) { rs.next(); inDb = rs.getLong(1); }
            System.out.printf("%nLoaded into database : %,d rows in %.0f ms (batch size 1,000, single transaction)%n", loaded, ms);
            System.out.printf("SELECT COUNT(*)       : %,d  -> %s%n", inDb, inDb == loaded ? "matches" : "MISMATCH");
            System.out.printf("Summary               : read %d = loaded %d + rejected %d%n", lineNo, loaded, failed.size());
        }
    }
}
