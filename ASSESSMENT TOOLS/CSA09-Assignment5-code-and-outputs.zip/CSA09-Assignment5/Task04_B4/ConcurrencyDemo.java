import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** B4.3 - several counters issuing passes at the same time: shared FILE (read-modify-write) vs shared DATABASE. */
public class ConcurrencyDemo {
    static final int COUNTERS = 4, PER = 250;

    public static void main(String[] args) throws Exception {
        // ---------- (1) naive shared text file: each counter reads whole file, adds its line, rewrites whole file
        Path f = Paths.get("shared_passes.csv"); Files.deleteIfExists(f); Files.createFile(f);
        AtomicInteger ioErrors = new AtomicInteger();
        ExecutorService ex = Executors.newFixedThreadPool(COUNTERS);
        CountDownLatch go = new CountDownLatch(1); List<Future<?>> fs = new ArrayList<>();
        for (int c = 0; c < COUNTERS; c++) { final int cc = c;
            fs.add(ex.submit(() -> { go.await();
                for (int i = 0; i < PER; i++) {
                    try { List<String> lines = new ArrayList<>(Files.readAllLines(f));
                          lines.add(String.format("C%d-P%04d,192311000,Student,1,4500.0", cc, i));
                          Files.write(f, lines); }
                    catch (IOException e) { ioErrors.incrementAndGet(); }
                } return null; })); }
        go.countDown(); for (Future<?> x : fs) x.get(); ex.shutdown();
        int expected = COUNTERS * PER; int actual = Files.readAllLines(f).size();
        System.out.println("=== (1) Shared text file, " + COUNTERS + " counters x " + PER + " passes, no locking ===");
        System.out.printf("    passes issued = %d, passes in file = %d, LOST = %d, I/O errors = %d%n", expected, actual, expected - actual, ioErrors.get());
        Files.delete(f);

        // ---------- (2) shared database, one connection per counter, auto-commit per insert
        String url = Migrate.URL;
        try (Connection admin = DriverManager.getConnection(url, "pass_user", "pass@123")) {
            try (Statement st = admin.createStatement()) { st.execute("TRUNCATE TABLE bus_pass"); }
            ExecutorService ex2 = Executors.newFixedThreadPool(COUNTERS); CountDownLatch go2 = new CountDownLatch(1); List<Future<?>> f2 = new ArrayList<>();
            for (int c = 0; c < COUNTERS; c++) { final int cc = c;
                f2.add(ex2.submit(() -> { go2.await();
                    try (Connection con = DriverManager.getConnection(url, "pass_user", "pass@123");
                         PreparedStatement ps = con.prepareStatement("INSERT INTO bus_pass VALUES (?,?,?,?,?)")) {
                        for (int i = 0; i < PER; i++) { ps.setString(1, String.format("C%d-P%04d", cc, i)); ps.setString(2, "192311000"); ps.setString(3, "Student"); ps.setInt(4, 1); ps.setDouble(5, 4500.0); ps.executeUpdate(); }
                    } return null; })); }
            go2.countDown(); for (Future<?> x : f2) x.get(); ex2.shutdown();
            long rows; try (Statement st = admin.createStatement(); ResultSet r = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) { r.next(); rows = r.getLong(1); }
            System.out.println("\n=== (2) Shared database, " + COUNTERS + " counters x " + PER + " passes at the same time ===");
            System.out.printf("    passes issued = %d, rows in table = %d, LOST = %d%n", expected, rows, expected - rows);
            // duplicate pass id from two counters
            try (PreparedStatement ps = admin.prepareStatement("INSERT INTO bus_pass VALUES (?,?,?,?,?)")) {
                ps.setString(1, "C0-P0000"); ps.setString(2, "192311000"); ps.setString(3, "Duplicate"); ps.setInt(4, 1); ps.setDouble(5, 1.0);
                ps.executeUpdate(); System.out.println("    duplicate pass id accepted (BAD)");
            } catch (SQLIntegrityConstraintViolationException e) { System.out.println("    second counter issuing the SAME pass id C0-P0000 -> rejected by PRIMARY KEY: " + e.getMessage().split("\n")[0]); }
        }
    }
}
