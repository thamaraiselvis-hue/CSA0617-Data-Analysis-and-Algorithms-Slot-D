import java.nio.file.*;
import java.util.*;

/** builds the "existing" pass file: 20,000 good records + deliberately damaged lines */
public class MakeOldFile {
    public static void main(String[] a) throws Exception {
        List<String> l = new ArrayList<>();
        Random r = new Random(7);
        for (int i = 1; i <= 20000; i++)
            l.add(String.join(",", String.format("P%06d", i), String.format("19%07d", i), "Student" + i, String.valueOf(r.nextInt(40) + 1), String.valueOf(3000 + 100 * r.nextInt(20))));
        l.add(5000, "P900001,192311001,Short,12");                         // wrong field count
        l.add(8000, "");                                                    // empty line
        l.add(9000, "P900002,192311002,BadAmt,7,FORTY");                    // non-numeric amount
        l.add(12000, "P900003,19231100,ShortReg,7,3800.0");                 // register number not 9 digits
        l.add(15000, "P000010,192311999,DupId,7,3800.0");                   // duplicate of existing P000010
        l.add(17000, "P900004,192311004,NegAmt,7,-500.0");                  // negative amount
        l.add(18000, "P900005,192311005,Route,ABC,3800.0");                 // non-numeric route
        l.add(19000, "P900006,192311006,Kumar%2C A,9,4100.0");              // GOOD: encoded comma
        Files.write(Paths.get("old_passes.csv"), l);
        System.out.println("old_passes.csv written with " + l.size() + " lines");
    }
}
