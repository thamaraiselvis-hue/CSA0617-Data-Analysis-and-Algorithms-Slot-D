import java.nio.file.*;
import java.util.*;

/** B2 - construct a damaged bus-pass file and show how the file store responds. */
public class DamagedFileDemo {
    public static void main(String[] args) throws Exception {
        Path f = Paths.get("damaged_passes.csv");
        List<String> lines = List.of(
            "P2001,192311001,Arun,12,4500.0",                 // 1  good
            "P2002,192311002,Meena,7",                        // 2  too FEW fields (4)
            "P2003,192311003,Divya,12,4200.0,EXTRA",          // 3  too MANY fields (6)
            "P2004,192311004,Karthik,7,FORTY-FIVE",           // 4  non-numeric amount
            "",                                               // 5  empty line
            "P2006,192311006,Latha,ABC,3800.0",               // 6  non-numeric route
            ",192311007,NoId,7,3800.0",                       // 7  empty pass id
            "P2008,192311008,Ravi,7,3900.0");                 // 8  good
        Files.write(f, lines);
        PassStore s = new PassStore(f);

        System.out.println("Damaged file (" + lines.size() + " lines):");
        for (int i = 0; i < lines.size(); i++) System.out.printf("  line %d : [%s]%n", i + 1, lines.get(i));

        System.out.println("\nLine-by-line verdict of the strict parser:");
        for (int i = 0; i < lines.size(); i++) {
            String[] r = PassStore.parseStrict(lines.get(i));
            String why = lines.get(i).isBlank() ? "empty line" : (lines.get(i).split(",", -1).length != 5 ? "field count = " + lines.get(i).split(",", -1).length
                      : (r == null ? "bad number / empty ID" : "ok"));
            System.out.printf("  line %d : %-8s (%s)%n", i + 1, r == null ? "REJECTED" : "accepted", why);
        }

        System.out.println("\nfind(\"P2004\")          [given code, only checks 5 fields]  -> " + Arrays.toString(s.find("P2004")));
        System.out.println("findValidated(\"P2004\") [also checks numbers]               -> " + Arrays.toString(s.findValidated("P2004")) + "  (damagedSkipped=" + s.damagedSkipped + ")");
        System.out.println("find(\"P2002\")          -> " + Arrays.toString(s.find("P2002")));
        System.out.println("findValidated(\"P2008\") (record after all damaged lines) -> " + Arrays.toString(s.findValidated("P2008")));
        List<String[]> r7 = s.listByRoute(7);
        System.out.println("listByRoute(7)         -> " + r7.size() + " valid passes: " + r7.stream().map(x -> x[0]).toList() + "  (damagedSkipped=" + s.damagedSkipped + ")");
        Files.delete(f);
    }
}
