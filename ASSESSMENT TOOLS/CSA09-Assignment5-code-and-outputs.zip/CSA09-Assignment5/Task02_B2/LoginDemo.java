import java.sql.*;

/** B2 - unsafe (string concatenation) login vs PreparedStatement login, on the local test database. */
public class LoginDemo {
    static final String URL = "jdbc:mariadb://localhost:3306/transport_test";

    static boolean unsafeLogin(Connection con, String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        System.out.println("      SQL built : " + sql);
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next();
        } catch (SQLException e) {
            System.out.println("      SQL error : " + e.getMessage().split("\n")[0]);
            return false;
        }
    }

    static boolean safeLogin(Connection con, String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id = ? AND pwd = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public static void main(String[] args) throws Exception {
        String[][] cases = {
            {"admin",          "Secret@123",   "valid user, valid password"},
            {"admin",          "wrongpass",    "valid user, WRONG password"},
            {"admin",          "' OR '1'='1",  "attack 1: tautology in password"},
            {"admin' -- ",     "anything",     "attack 2: comment out password check"},
            {"x' OR '1'='1' -- ", "zzz",       "attack 3: unknown user, always-true"},
        };
        try (Connection con = DriverManager.getConnection(URL, "pass_user", "pass@123")) {
            System.out.println("=== UNSAFE version (string concatenation) ===");
            for (String[] c : cases) {
                System.out.println("  Case: " + c[2] + "   id=[" + c[0] + "]  pwd=[" + c[1] + "]");
                boolean ok = unsafeLogin(con, c[0], c[1]);
                System.out.println("      RESULT    : " + (ok ? "LOGIN ACCEPTED" : "login rejected"));
            }
            System.out.println("\n=== SAFE version (PreparedStatement, ? placeholders) ===");
            for (String[] c : cases) {
                boolean ok = safeLogin(con, c[0], c[1]);
                System.out.println("  Case: " + c[2] + "   id=[" + c[0] + "]  pwd=[" + c[1] + "]");
                System.out.println("      RESULT    : " + (ok ? "LOGIN ACCEPTED" : "login rejected"));
            }
        }
    }
}
