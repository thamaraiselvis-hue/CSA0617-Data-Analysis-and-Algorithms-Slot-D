import java.sql.*;
import java.util.regex.*;

/** B2 Alternative - cost per query of regex validation / quote escaping versus PreparedStatement binding and execution. */
public class ValidationCost {
    static final Pattern SAFE = Pattern.compile("^[A-Za-z0-9_@#.-]{1,20}$");
    static String escape(String s) { return s.replace("\\", "\\\\").replace("'", "''"); }
    public static void main(String[] args) throws Exception {
        String id = "admin", pwd = "Secret@123"; int N = 1_000_000; long sink = 0;
        for (int i = 0; i < 200000; i++) { sink += SAFE.matcher(id).matches() ? 1 : 0; sink += escape(pwd).length(); }
        long t = System.nanoTime(); for (int i = 0; i < N; i++) sink += SAFE.matcher(id).matches() && SAFE.matcher(pwd).matches() ? 1 : 0;
        double regexNs = (System.nanoTime() - t) / (double) N;
        t = System.nanoTime(); for (int i = 0; i < N; i++) sink += (escape(id) + escape(pwd)).length();
        double escNs = (System.nanoTime() - t) / (double) N;
        try (Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/transport_test", "pass_user", "pass@123");
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE id = ? AND pwd = ?")) {
            for (int i = 0; i < 300; i++) { ps.setString(1, id); ps.setString(2, pwd); try (ResultSet r = ps.executeQuery()) { r.next(); } }
            t = System.nanoTime(); for (int i = 0; i < N; i++) { ps.setString(1, id); ps.setString(2, pwd); }
            double bindNs = (System.nanoTime() - t) / (double) N;
            int Q = 3000; t = System.nanoTime();
            for (int i = 0; i < Q; i++) { ps.setString(1, id); ps.setString(2, pwd); try (ResultSet r = ps.executeQuery()) { r.next(); } }
            double execUs = (System.nanoTime() - t) / (double) Q / 1e3;
            System.out.printf("Regex validation of id+pwd      : %8.1f ns per login%n", regexNs);
            System.out.printf("Quote escaping of id+pwd        : %8.1f ns per login%n", escNs);
            System.out.printf("PreparedStatement setString x2  : %8.1f ns per login (binding only)%n", bindNs);
            System.out.printf("Whole query round trip (execute): %8.1f us per login (same for every approach)%n", execUs);
        }
        if (sink == 42) System.out.println();
    }
}
